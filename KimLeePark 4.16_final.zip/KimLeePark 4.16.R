# 참고자료 : 2022년 문화예술활동 공간 1년 이내 이용여부 및 이용횟수
library(svDialogs)
Restplace <- read.csv('RestPlace.csv', fileEncoding = "CP949", encoding = "UTF-8")
Restplace
# 요약본 출력
str(Restplace)


#1. 연령별 문화시설을 이용한 비율의 평균을 구하시오.
temp <- function(name){
  Restplace.type <- subset(Restplace, 통계분류.1. == name)  #통계분류.1.에서 name에 해당하는 값을 저장
  return(mean(Restplace.type$이용함)) #해당 값의 평균을 구해 반환
}

temp("연령별")


#2. 17개 시도별로 지역마다 문화시설 이용여부 중 비교적 더 큰 선택지와 선택지의 비율을 포함하는 매트릭스를 출력하시오. 
Local <- subset(Restplace, 통계분류.1. == "17개 시도별") #통계 中 17개 시도별 항목 값 추출 
Local

for(i in 1:17){
  if(Local[i,4] > Local[i,5]){
    local.info <- c(Local[i,2], Local[i,4], "문화시설 이용함")
  } else {
    local.info<-c(Local[i,2], Local[i,5], "문화시설 이용안함")
  }
  
  if(i == 1){
    Local_Total <- matrix(local.info, nrow = 1, ncol = 3, byrow = T)
  } else{
    total <- matrix(local.info, nrow = 1, ncol = 3, byrow = T)
    Local_Total <- rbind(Local_Total,total)
  }
}

colnames(Local_Total) <- c("지역", "이용여부 비율(%)", "문화시설 이용여부")
Local_Total


#3. 전체 표본 분류 중 이용횟수가 2.0이상인 표본의 비율을 구하시오. (1행 제외)
total <- sum(Restplace[Restplace$통계분류.1. != "전체" & Restplace$통계분류.2. != "소계", "표본수"])
usage <- 0
for (i in 1:nrow(Restplace)) {
  if (Restplace[i, "이용횟수"] >= 2.0) {
    usage <- usage + Restplace[i, "표본수"]
  }
}

result <- (usage / total) * 100
result


#4. 17개 시도별 문화시설 이용횟수가 2.0 이상인 지역과 해당 지역의 이용횟수를 출력하시오. (which 활용)
region.num <- Restplace[Restplace$통계분류.1. == "17개 시도별", "이용횟수"]
region.num <-as.numeric(region.num)
region.num
names(region.num) <- c('서울','부산','대구','인천','광주','대전',
                       '울산','세종','경기','강원','충북','충남',
                       '전북','전남','경북','경남','제주')

idx <- which(region.num >= 2)
region.num[idx]