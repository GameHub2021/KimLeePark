# 참고자료 : 살인범죄의 조별과 공용물
install.packages('readxl')
library(readxl)
library(svDialogs)
getwd()
setwd("C:\\Rworks")
GameMoneyRanking <- read_excel('GameRanking.xlsx', sheet = 1)
str(GameMoneyRanking)
GameMoneyRank <- table(GameMoneyRanking[1:21,3])
GameMoneyRank

#1-1. 24년 4월 모바일 게임 매출 Top20 中 자동사냥 기능을 가지고 있는 RPG게임 비중
install.packages("plotrix")
library(plotrix)
GameMoneyRank <- prop.table(GameMoneyRank)

pie_data <- table(GameMoneyRanking$장르)

# 원그래프 그리기
pie(pie_data, 
    main =  "24년 4월 모바일 게임 매출 Top20", 
    col = rainbow(length(pie_data)),
    label = paste(names(pie_data), paste0(GameMoneyRank*100, "%")),
    radius = 1)

#1-2. 24년 4월 모바일 게임 사용자 수 Top20 中 자동사냥 기능을 가지고 있는 RPG게임 비중
GameUseRanking <- read_excel('GameRanking.xlsx', sheet = 2)
str(GameUseRanking)
GameUseRank <- table(GameUseRanking[1:21,3])
GameUseRank

GameUseRank <- prop.table(GameUseRank)

pie_data <- table(GameUseRanking$장르)

# 원그래프 그리기
pie(pie_data, 
    main =  "24년 4월 모바일 게임 사용자 수 Top20", 
    col = rainbow(length(pie_data)),
    label = paste(names(pie_data), paste0(GameUseRank*100, "%")),
    radius = 1)

#1-3. 매출 Top20 中 자동사냥 기능을 가진 RPG게임의 최근 3개월(24.03 ~ 05) 매출
GameEarning <- read_excel('GameRanking.xlsx', sheet = 3)
str(GameEarning)
GameEarn <- GameEarning[1:7,2]
GameEarn <- t(GameEarn)
colnames(GameEarn) <- GameEarning$게임

# 막대 그래프 그리기
Earn_barplot <- barplot(GameEarn,
                        main = "매출 Top20 자동사냥 RPG게임 최근 3개월(24.03 ~ 05) 매출",
                        col = rainbow(length(GameEarn)),
                        xlab='게임',
                        ylab='매출 (단위 : 억)',
                        ylim = c(0,500),
                        beside = T)
text(x = Earn_barplot, y = GameEarn, labels = GameEarn, pos = 3)

#1-4. 매출 Top20 中 자동사냥 기능을 가진 RPG게임과 이용자 수 1, 2등 게임의 최근 3개월(24.03 ~ 05) 매출, 이용자 수 비교
Game_Compare <- read_excel('GameRanking.xlsx', sheet = 4)
str(Game_Compare)
GameCompare <- Game_Compare[1:9,2:3]
GameCompare <- as.matrix(GameCompare)
GameCompare
rownames(GameCompare) <- Game_Compare$게임
GameCompare


# 막대 그래프 그리기
par(mfrow=c(1, 1), mar=c(5, 5, 5, 10))
Compare_barplot <- barplot(t(GameCompare),
                           main = "매출 Top20 자동사냥 RPG게임과 이용자 수 1, 2등 게임 최근 3개월(24.03 ~ 05) 매출, 이용자 수 ",
                           col = c("yellow","green"),
                           xlab='게임',
                           legend.text=T,
                           args.legend = list(x = 'topright', bty = 'n', inset = c(-0.37,0), cex = 0.9),
                           ylim = c(0,700),
                           beside = T)
text(x = Compare_barplot, y = t(GameCompare), labels = t(GameCompare), pos = 3)


#2-1. 리니지 시리즈 개발사 엔씨소프트 매출 및 마케팅비 분석
Advertising1 <- read_excel('Advertising.xlsx', sheet = 1)
Advertising1
str(Advertising1)
Advertising1 <- as.matrix(Advertising1[1:2,2:4])
Advertising1

# 선 그래프 그리기
plot(1:3,
     Advertising1[1,1:3],
     main = "엔씨소프트 23.3 ~ 24.1분기 매출&마케팅비",
     type = 'b',
     lwd = 3,
     xlab = '분기',
     ylab = '단위 : 억',
     ylim = c(0,7000),
     col = c('green'),
     xaxt='n')

text(1:3, y = Advertising1[1,1:3], labels = Advertising1[1,1:3], pos = 3)

lines(1:3,
      Advertising1[2,1:3],
      type = 'b',
      lwd = 3,
      col = c('blue'),
      xaxt = 'n')
text(1:3, y = Advertising1[2,1:3], labels = Advertising1[2,1:3], pos = 3)

legend(x='topright',
       legend = c('매출 (단위 : 억 )', '마케팅비'), 
       col=c('green','blue'), 
       pch=1,
       bty = 'n',
       inset = c(-0.14,-0.16),
       cex = 1.2) 
axis(1, at=1:3, labels=c("23년 3분기", "23년 4분기", "24년 1분기"))

#2-2. 카카오 게임즈 매출 및 마케팅비 분석
Advertising2 <- read_excel('Advertising.xlsx', sheet = 2)
Advertising2
str(Advertising2)
Advertising2 <- as.matrix(Advertising2[1:2,2:4])
Advertising2

# 선 그래프 그리기
plot(1:3,
     Advertising2[1,1:3],
     main = "카카오게임즈 23.3 ~ 24.1분기 매출&마케팅비",
     type = 'b',
     lwd = 3,
     xlab = '분기',
     ylab = '단위 : 억',
     ylim = c(0,7000),
     col = c('green'),
     xaxt='n')
text(1:3, y = Advertising2[1,1:3], labels = Advertising2[1,1:3], pos = 3)

lines(1:3,
      Advertising2[2,1:3],
      type = 'b',
      lwd = 3,
      col = c('blue'),
      xaxt = 'n')
text(1:3, y = Advertising2[2,1:3], labels = Advertising2[2,1:3], pos = 3)

legend(x='topright',
       legend = c('매출 (단위 : 억 )', '마케팅비'), 
       col=c('green','blue'), 
       pch=1,
       bty = 'n',
       inset = c(-0.14,-0.16),
       cex = 1.2) 
axis(1, at=1:3, labels=c("23년 3분기", "23년 4분기", "24년 1분기"))

#2-3. 엔씨소프트와 넷마블 매출, 마케팅비 비교
Advertising1 <- read_excel('Advertising.xlsx', sheet = 1)
Advertising1
Advertising3 <- read_excel('Advertising.xlsx', sheet = 3)
Advertising3
str(Advertising1)
str(Advertising3)
Advertising1 <- as.matrix(Advertising1[1:2,2:4])
Advertising1
Advertising3 <- as.matrix(Advertising3[1:2,2:4])
Advertising3
Color <- rainbow(4)
Color

# 선 그래프 그리기
plot(1:3,
     Advertising1[1,1:3],
     main = "엔씨소프트, 넷마블 매출&마케팅비 비교",
     type = 'b',
     lwd = 3,
     xlab = '분기',
     ylab = '단위 : 억',
     ylim = c(0,10000),
     col = c(Color[1]),
     xaxt='n')
text(1:3, y = Advertising1[1,1:3], labels = Advertising1[1,1:3], pos = 3)

lines(1:3,
      Advertising1[2,1:3],
      type = 'b',
      lwd = 3,
      col = c(Color[2]),
      xaxt = 'n')
text(1:3, y = Advertising1[2,1:3], labels = Advertising1[2,1:3], pos = 3)

lines(1:3,
      Advertising3[1,1:3],
      type = 'b',
      lwd = 3,
      col = c(Color[3]),
      xaxt = 'n')
text(1:3, y = Advertising3[1,1:3], labels = Advertising3[1,1:3], pos = 3)

lines(1:3,
      Advertising3[2,1:3],
      type = 'b',
      lwd = 3,
      col = c(Color[4]),
      xaxt = 'n')
text(1:3, y = Advertising3[2,1:3], labels = Advertising3[2,1:3], pos = 3)

legend(x='topright',
       legend = c('엔씨소프트 매출', '엔씨소프트 마케팅비', '넷마블 매출', '넷마블 마케팅비'), 
       col= rainbow(4), 
       pch=1,
       bty = 'n',
       inset = c(-0.1,-0.08),
       cex = 0.55) 
axis(1, at=1:3, labels=c("23년 3분기", "23년 4분기", "24년 1분기"))

#2-4. 카카오게임즈와 웹젠 매출, 마케팅비 비교
Advertising2 <- read_excel('Advertising.xlsx', sheet = 2)
Advertising2
Advertising4 <- read_excel('Advertising.xlsx', sheet = 4)
Advertising4
str(Advertising2)
str(Advertising4)
Advertising2 <- as.matrix(Advertising2[1:2,2:4])
Advertising2
Advertising4 <- as.matrix(Advertising4[1:2,2:4])
Advertising4
Color <- rainbow(4)
Color

# 선 그래프 그리기
plot(1:3,
     Advertising2[1,1:3],
     main = "카카오게임즈, 웹젠 매출&마케팅비 비교",
     type = 'b',
     lwd = 3,
     xlab = '분기',
     ylab = '단위 : 억',
     ylim = c(0,4000),
     col = c(Color[1]),
     xaxt='n')
text(1:3, y = Advertising2[1,1:3], labels = Advertising2[1,1:3], pos = 3)

lines(1:3,
      Advertising2[2,1:3],
      type = 'b',
      lwd = 3,
      col = c(Color[2]),
      xaxt = 'n')
text(1:3, y = Advertising2[2,1:3], labels = Advertising2[2,1:3], pos = 3)

lines(1:3,
      Advertising4[1,1:3],
      type = 'b',
      lwd = 3,
      col = c(Color[3]),
      xaxt = 'n')
text(1:3, y = Advertising4[1,1:3], labels = Advertising4[1,1:3], pos = 3)

lines(1:3,
      Advertising4[2,1:3],
      type = 'b',
      lwd = 3,
      col = c(Color[4]),
      xaxt = 'n')
text(1:3, y = Advertising4[2,1:3], labels = Advertising4[2,1:3], pos = 1)

legend(x='topright',
       legend = c('카카오게임즈 매출', '카카오게임즈 마케팅비', '웹젠 매출', '웹젠 마케팅비'), 
       col= rainbow(4), 
       pch=1,
       bty = 'n',
       inset = c(-0.1,-0.08),
       cex = 0.55) 
axis(1, at=1:3, labels=c("23년 3분기", "23년 4분기", "24년 1분기"))

#3.리니지m, 리니지2m 6년간 유저 연령별 비율 (리니지m : 6년, 리니지2m : 4년)
LineageUser <- read_excel('LineageUser.xlsx', sheet = 1)
str(LineageUser)
LineageUser <- as.matrix(LineageUser[1:4,2:3])
LineageUser
rownames(LineageUser) <- c('18~24', '25~34', '35~44', '45+')

par(mfrow=c(1, 2), mar=c(5, 5, 5, 10))
Lineage.m_barplot <- barplot(LineageUser[1:4,1],
                           main = "리니지m 6년간(17.6 ~ 23.2) 유저 연령별 비율",
                           col = c("yellow"),
                           xlab = '연령대',
                           ylab = 'Percentage',
                           ylim = c(0,100),
                           space = 0)
text(x = Lineage.m_barplot, y = LineageUser[1:4,1], labels = paste(LineageUser[1:4,1], "%"), pos = 3)

Lineage.2m_barplot <- barplot(LineageUser[1:4,2],
                              main = "리니지2m 4년간(19.11 ~ 23.2) 유저 연령별 비율",
                              col = c("green"),
                              xlab = '연령대',
                              ylab = 'Percentage',
                              ylim = c(0,100),
                              space = 0)
text(x = Lineage.2m_barplot, y = LineageUser[1:4,2], labels = paste(LineageUser[1:4,2], "%"), pos = 3)

#4-1. 메이플스토리M 유저 연령대 분포 그래프
MapleStoryM <- read_excel('UserAge.xlsx', sheet = 1)
str(MapleStoryM)
MapleStoryM <- as.data.frame(MapleStoryM[1:4,2:9])
MapleStoryM
Color <- rainbow(4)
Color

# 선 그래프 그리기
plot(1:8,
     MapleStoryM[1,],
     main = "메이플스토리M 유저 연령대 분포",
     type = 'b',
     lwd = 3,
     xlab = '23.5 ~ .12',
     ylab = 'Percentage',
     ylim = c(0,100),
     col = c(Color[1]),
     xaxt='n')
text(1:8, y = MapleStoryM[1,], labels = MapleStoryM[1,], pos = 3, cex = 0.8)

lines(1:8,
      MapleStoryM[2,],
      type = 'b',
      lwd = 3,
      col = c(Color[2]),
      xaxt = 'n')
text(1:8, y = MapleStoryM[2,], labels = MapleStoryM[2,], pos = 3, cex = 0.8)

lines(1:8,
      MapleStoryM[3,],
      type = 'b',
      lwd = 3,
      col = c(Color[3]),
      xaxt = 'n')
text(1:8, y = MapleStoryM[3,], labels = MapleStoryM[3,], pos = 1, cex = 0.8)

lines(1:8,
      MapleStoryM[4,],
      type = 'b',
      lwd = 3,
      col = c(Color[4]),
      xaxt = 'n')
text(1:8, y = MapleStoryM[4,], labels = MapleStoryM[4,], pos = 3, cex = 0.8)

legend(x='topright',
       legend = c('18 ~ 24', '25 ~ 34', '34 ~ 44', '45+'), 
       col = rainbow(4), 
       pch = 1,
       bty = 'n',
       inset = c(-0.05,-0.1),
       cex = 0.8) 
axis(1, at=1:8, labels=c('23-05',	'23-06',	'23-07',	'23-08',	'23-09',	'23-10',	'23-11',	'23-12'))

#4-2. 리니지w 유저 연령대 분포 그래프
LineageW <- read_excel('UserAge.xlsx', sheet = 2)
str(LineageW)
LineageW <- as.data.frame(LineageW[1:4,2:9])
LineageW[1,3] <- as.numeric(LineageW[1,3], 1)
LineageW
Color <- rainbow(4)
Color

# 선 그래프 그리기
plot(1:8,
     LineageW[1,],
     main = "리니지w 유저 연령대 분포",
     type = 'b',
     lwd = 3,
     xlab = '23.5 ~ .12',
     ylab = 'Percentage',
     ylim = c(0,100),
     col = c(Color[1]),
     xaxt='n')
text(1:8, y = LineageW[1,], labels = LineageW[1,], pos = 3, cex = 0.8)

lines(1:8,
      LineageW[2,],
      type = 'b',
      lwd = 3,
      col = c(Color[2]),
      xaxt = 'n')
text(1:8, y = LineageW[2,], labels = LineageW[2,], pos = 3, cex = 0.8)

lines(1:8,
      LineageW[3,],
      type = 'b',
      lwd = 3,
      col = c(Color[3]),
      xaxt = 'n')
text(1:8, y = LineageW[3,], labels = LineageW[3,], pos = 1, cex = 0.8)

lines(1:8,
      LineageW[4,],
      type = 'b',
      lwd = 3,
      col = c(Color[4]),
      xaxt = 'n')
text(1:8, y = LineageW[4,], labels = LineageW[4,], pos = 3, cex = 0.8)

legend(x='topright',
       legend = c('18 ~ 24', '25 ~ 34', '34 ~ 44', '45+'), 
       col = rainbow(4), 
       pch = 1,
       bty = 'n',
       inset = c(-0.05,-0.1),
       cex = 0.8) 
axis(1, at=1:8, labels=c('23-05',	'23-06',	'23-07',	'23-08',	'23-09',	'23-10',	'23-11',	'23-12'))

#4-3. 2023년도 대한민국 연령별 실업률과 취업률 비교 그래프
LoseJob <- read_excel('Job_Percent.xlsx', sheet = 1)
str(LoseJob)
LoseJob <- as.data.frame(LoseJob[1:6,2:5])
LoseJob

EarnJob <- read_excel('Job_Percent.xlsx', sheet = 2)
str(LoseJob)
EarnJob <- as.data.frame(EarnJob[1:6,2:5])
EarnJob

Color <- rainbow(6)
Color

# 선 그래프 그리기
par(mfrow=c(1, 2), mar=c(5, 5, 5, 7))
plot(1:4,
     LoseJob[1,],
     main = "2023년도 대한민국 연령별 실업률",
     type = 'b',
     lwd = 1,
     xlab = '2023년 1~4분기',
     ylab = 'Percentage',
     ylim = c(0,20),
     col = c(Color[1]),
     xaxt='n')

lines(1:4,
      LoseJob[2,],
      type = 'b',
      lwd = 1,
      col = c('orange'),
      xaxt = 'n')

lines(1:4,
      LoseJob[3,],
      type = 'b',
      lwd = 1,
      col = c(Color[3]),
      xaxt = 'n')

lines(1:4,
      LoseJob[4,],
      type = 'b',
      lwd = 1,
      col = c(Color[4]),
      xaxt = 'n')

lines(1:4,
      LoseJob[5,],
      type = 'b',
      lwd = 1,
      col = c(Color[5]),
      xaxt = 'n')

lines(1:4,
      LoseJob[6,],
      type = 'b',
      lwd = 1,
      col = c(Color[6]),
      xaxt = 'n')

legend(x='topright',
       legend = c('15 ~ 19세', '20 ~ 29세', '30 ~ 39세', '40 ~ 49세', '50 ~ 59세', '60세 이상'), 
       col = c(Color[1], 'orange', Color[3:6]), 
       pch = 1,
       bty = 'n',
       inset = c(-0.35, -0.1),
       cex = 0.6) 

axis(1, at=1:4, labels=c('23-1분기', '23-2분기', '23-3분기', '23-4분기'))

plot(1:4,
     EarnJob[1,],
     main = "2023년도 대한민국 연령별 취업률",
     type = 'b',
     lwd = 1,
     xlab = '2023년 1~4분기',
     ylab = 'Percentage',
     ylim = c(80,100),
     col = c(Color[1]),
     xaxt='n')

lines(1:4,
      EarnJob[2,],
      type = 'b',
      lwd = 1,
      col = c('orange'),
      xaxt = 'n')

lines(1:4,
      EarnJob[3,],
      type = 'b',
      lwd = 1,
      col = c(Color[3]),
      xaxt = 'n')

lines(1:4,
      EarnJob[4,],
      type = 'b',
      lwd = 1,
      col = c(Color[4]),
      xaxt = 'n')

lines(1:4,
      EarnJob[5,],
      type = 'b',
      lwd = 1,
      col = c(Color[5]),
      xaxt = 'n')

lines(1:4,
      EarnJob[6,],
      type = 'b',
      lwd = 1,
      col = c(Color[6]),
      xaxt = 'n')

legend(x='topright',
       legend = c('15 ~ 19세', '20 ~ 29세', '30 ~ 39세', '40 ~ 49세', '50 ~ 59세', '60세 이상'), 
       col = c(Color[1], 'orange', Color[3:6]), 
       pch = 1,
       bty = 'n',
       inset = c(-0.35, 0.28),
       cex = 0.6) 

axis(1, at=1:4, labels=c('23-1분기', '23-2분기', '23-3분기', '23-4분기'))

#5-1. 엔씨소프트 최근 5년(2019~23) 모바일 게임 매출 추이
NCsoftEarning <- read_excel('GameDecrease.xlsx', sheet = 1)
str(NCsoftEarning)
NC.earning <- as.vector(NCsoftEarning[1,2:6])
NC.earning

#선 그래프 그리기
par(mfrow=c(1, 2), mar=c(5, 5, 5, 7))
plot(1:5,
     NC.earning,
     main = '2019 ~ 23년 엔씨소프트 모바일 게임 매출',
     type = 'b',
     lwd = 3,
     xlab = '연도',
     ylab = '매출 (단위 : 억)',
     ylim = c(0, 20000),
     col = c(Color[1]),
     xaxt='n')
text(x = 1:5, y = NC.earning, labels = NC.earning, pos = 3, cex = 0.8)
axis(1, at=1:5, labels=c("2019년", "2020년", "2021년", "2022년", "2023년"))

#먁대그래프 그리기
NC.earning_per <- c()
NC.earning <- as.numeric(NC.earning)
for(i in 1:4){
  NC.earning_per <- c(NC.earning_per, round((NC.earning[i+1] - NC.earning[i]) / NC.earning[i] * 100, 1))
}
NC.earning_per
bar_colors <- ifelse(NC.earning_per > 0, "orange", "skyblue")
NC_barplot <- barplot(NC.earning_per,
                      main = '2019~23년 엔씨소프트 전년 대비 매출 증감 비율',
                      ylab = 'Percentage',
                      ylim = c(-100, 100),
                      space = 0,
                      beside = T,
                      col = bar_colors)
text(x = NC_barplot, y = NC.earning_per-3, labels = paste(NC.earning_per,"%"), pos = 3, cex = 1)
axis(1, at=NC_barplot, labels=c("19-20", "20-21", "21-22", "22-23"))

#5-2. 뮤 아크엔젤 확률 조작 이후 매출, 설치자 수 추이
MU.ark1 <- read_excel('GameDecrease.xlsx', sheet = 2)
str(MU.ark1)
MU.ark1 <- as.vector(MU.ark1[1,2:6])
MU.ark1

MU.ark2 <- read_excel('GameDecrease.xlsx', sheet = 3)
str(MU.ark2)
MU.ark2 <- as.vector(MU.ark2[1,2:10])
MU.ark2

#막대 그래프 그리기
par(mfrow=c(1, 2), mar=c(5, 5, 5, 7))
MU.earning_per <- c()
MU.ark1 <- as.numeric(MU.ark1)
for(i in 1:4){
  MU.earning_per <- c(MU.earning_per, round((MU.ark1[i+1] - MU.ark1[i]) / MU.ark1[i] * 100, 1))
}
MU.earning_per
bar_colors <- ifelse(MU.earning_per > 0, "orange", "skyblue")
MU_barplot <- barplot(MU.earning_per,
                      main = '23.12~24.04 뮤 아크엔젤 월간 매출 증감 비율',
                      ylab = 'Percentage',
                      ylim = c(-100, 100),
                      space = 0,
                      beside = T,
                      col = bar_colors)
text(x = MU_barplot, y = MU.earning_per-3, labels = paste(MU.earning_per,"%"), pos = 3, cex = 1)
axis(1, at=MU_barplot, labels=c("23.12-24.01", "24.01-24.02", "24.02-24.03", "24.03-24.04"))

MU.user_per <- c()
MU.ark2 <- as.numeric(MU.ark2)
for(i in 1:8){
  MU.user_per <- c(MU.user_per, round((MU.ark2[i+1] - MU.ark2[i]) / MU.ark2[i] * 100, 1))
}
MU.user_per
bar_colors <- ifelse(MU.user_per > 0, "orange", "skyblue")
MU_barplot2 <- barplot(MU.user_per,
                       main = '24년 3월 1주차~5월 1주차 뮤 아크엔젤 주간 설치자 수 증감 비율',
                       ylab = 'Percentage',
                       ylim = c(-100, 100),
                       space = 0,
                       beside = T,
                       col = bar_colors)
text(x = MU_barplot2, y = MU.user_per-3, labels = paste(MU.user_per,"%"), pos = 3, cex = 1)
axis(1, at=MU_barplot2, labels=c("3월 1-2주", "2-3주", "3-4주", "4-1주", "4월 1-2주", "2-3주", "3-4주", "4-1주"))

#5-3. 나이트 크로우 확률 조작 이후 매출, 설치자 수 추이
Crow1 <- read_excel('GameDecrease.xlsx', sheet = 4)
str(Crow1)
Crow1 <- as.vector(Crow1[1,2:6])
Crow1

Crow2 <- read_excel('GameDecrease.xlsx', sheet = 5)
str(Crow2)
Crow2 <- as.vector(Crow2[1,2:10])
Crow2

#막대 그래프 그리기
par(mfrow=c(1, 2), mar=c(5, 5, 5, 7))
CR.earning_per <- c()
Crow1 <- as.numeric(Crow1)
for(i in 1:4){
  CR.earning_per <- c(CR.earning_per , round((Crow1[i+1] - Crow1[i]) / Crow1[i] * 100, 1))
}
CR.earning_per
bar_colors <- ifelse( CR.earning_per > 0, "orange", "skyblue")
CR_barplot <- barplot(CR.earning_per,
                      main = '23.12~24.04 나이트 크로우 월간 매출 증감 비율',
                      ylab = 'Percentage',
                      ylim = c(-100, 100),
                      space = 0,
                      beside = T,
                      col = bar_colors)
text(x = CR_barplot, y = CR.earning_per-2, labels = paste(CR.earning_per,"%"), pos = 3, cex = 1)
axis(1, at=CR_barplot, labels=c("23.12-24.01", "24.01-24.02", "24.02-24.03", "24.03-24.04"))

CR.user_per <- c()
Crow2 <- as.numeric(Crow2)
for(i in 1:8){
  CR.user_per <- c(CR.user_per, round((Crow2[i+1] - Crow2[i]) / Crow2[i] * 100, 1))
}
CR.user_per
bar_colors <- ifelse(CR.user_per > 0, "orange", "skyblue")
CR_barplot2 <- barplot(CR.user_per,
                       main = '24년 3월 1주차~5월 1주차 나이트 크로우 주간 설치자 수 증감 비율',
                       ylab = 'Percentage',
                       ylim = c(-100, 100),
                       space = 0,
                       beside = T,
                       col = bar_colors)
text(x = CR_barplot2, y = CR.user_per-2, labels = paste(CR.user_per,"%"), pos = 3, cex = 1)
axis(1, at=CR_barplot2, labels=c("3월 1-2주", "2-3주", "3-4주", "4-1주", "4월 1-2주", "2-3주", "3-4주", "4-1주"))

#5-4. 뮤 아크엔젤, 나이트 크로우 확률 조작 이후 유저 평점 추이 
install.packages("ggplot2")
library(ggplot2)
Evaluation <- read_excel('Evaluation.xlsx', sheet = 1)
str(Evaluation) 
Evaluation <- as.matrix(Evaluation)

#박스 그림 그래프 그리기
par(mfrow=c(1, 2), mar=c(5, 5, 5, 7))
Evaluation1 <- c()
Evaluation2 <- c()
Evaluation3 <- c()
Evaluation4 <- c()
Evaluation5 <- c()

for(i in 1:Evaluation[1,2]){
  Evaluation1 <- c(Evaluation1, 1)
}

for(i in 1:Evaluation[2,2]){
  Evaluation2 <- c(Evaluation2, 2)
}

for(i in 1:Evaluation[3,2]){
  Evaluation3 <- c(Evaluation3, 3)
}

for(i in 1:Evaluation[4,2]){
  Evaluation4 <- c(Evaluation4, 4)
}

for(i in 1:Evaluation[5,2]){
  Evaluation5 <- c(Evaluation5, 5)
}

Evaluation1 <- c(Evaluation1, Evaluation2, Evaluation3, Evaluation4, Evaluation5)
Evaluation1

bp <- boxplot(Evaluation1,
              main = '뮤 아크엔젤 평점 추이',
              xlab = '뮤 아크엔젤',
              ylab = '유저 평점')
boxplot.stats(Evaluation1)
points(1, bp$stats[3,], pch = 19, col = "red")
text(1, bp$stats[3,], labels = bp$stats[3,], pos = 3 )

evaluation <- read_excel('Evaluation.xlsx', sheet = 1)
str(evaluation) 
evaluation <- as.matrix(evaluation)

evaluation1 <- c()
evaluation2 <- c()
evaluation3 <- c()
evaluation4 <- c()
evaluation5 <- c()

for(i in 1:evaluation[1,3]){
  evaluation1 <- c(evaluation1, 1)
}

for(i in 1:evaluation[2,3]){
  evaluation2 <- c(evaluation2, 2)
}

for(i in 1:evaluation[3,3]){
  evaluation3 <- c(evaluation3, 3)
}

for(i in 1:evaluation[4,3]){
  evaluation4 <- c(evaluation4, 4)
}

for(i in 1:evaluation[5,3]){
  evaluation5 <- c(evaluation5, 5)
}

evaluation1 <- c(evaluation1, evaluation2, evaluation3, evaluation4, evaluation5)
evaluation1
bp <- boxplot(evaluation1,
              main = '나이트 크로우 평점 추이',
              xlab = '나이트 크로우',
              ylab = '유저 평점')
points(1, bp$stats[3,], pch = 19, col = "red")
text(1, bp$stats[3,], labels = bp$stats[3,], pos = 3 )
boxplot.stats(evaluation1)
