# 참고자료 : 살인범죄의 조별과 공용물
library(svDialogs)
getwd()
setwd("C:\\Rworks")
Murder <- read.csv('murder.csv', fileEncoding = "CP949", encoding = "UTF-8")
str(Murder)

#1. 합계를 제외한 도수분포를 작성하시오.
tmp <- Murder[2:10,3:9] # 총기~무기없음, 1인~10인이하
rownames(tmp) <- Murder[2:10, 1] # 이름 지정
tmp

#1-1. 1인 범죄자가 사람을 죽이는데 사용한 무기 개수의 상대도수를 구하시오.
one <- prop.table(tmp$X1인) # tmp 중 1인에 해당하는 요소의 상대도수
names(one) <- Murder[2:10, 1] # 이름 지정
one


#2. x축을 살인 건수, y축을 조별로 하는 무기마다 살인 건수의 수치를 보여주는 가로 막대 그래프를 그리시오.
murder_data <- Murder[2:10, 3:9]
murder_data
par(mfrow=c(1, 1), mar=c(5, 5, 5, 7)) 
barplot(as.matrix(murder_data),
        main = '살인범죄의 조별과 공용물',
        col = rainbow(9), 
        horiz = T, beside=T, legend.text=c("총기", "도검"," 도끼","낫","독극물","줄(끈)","돌","기타","무기 없음"), las=1,
        args.legend = list(x='topright', bty='n',inset=c(-0.25,0), cex = 0.5),
        xlab = "수치 (단위: 건)", ylab="조별", width=2.5)


#3. 살인도구를 x축으로 범죄 건수를 y축으로 하는 무기마다 살인범죄 조별 비율을 반영한 세로 막대 그래프를 그리시오.
barplot(t(Murder[, -(1:2)]), beside = FALSE, col = rainbow(7),
        names.arg = Murder$공용물별, main = "살인범죄의 조별과 공용물",
        xlab = "살인 도구", ylab = "범죄 건수",
        legend.text = c("1인","2인","3인","4인","5인","6인","10인이하"),
        args.legend = list(x='topright', bty='n', inset =c(0,0), cex = 0.5),
        ylim = c(0,200))


#4. 살인범죄 공용뮬 사용 빈도를 원형 그래프로 표현하시오.
Murder_weapon <- Murder[2:10,2]
Murder_weapon

names(Murder_weapon) <- Murder[2:10,1]
pie(Murder_weapon,
    main =  "살인범죄 공용물 사용 빈도",
    col = rainbow(length(Murder_weapon)),
    labels = paste(Murder[2:10,1], ":", Murder[2:10,2]),
    radius =  1)

legend(1.3, 1, names(Murder_weapon), fill = rainbow(length(Murder_weapon)), cex = 0.6)

#4-1. 살인범죄 공용뮬 사용 빈도를 3D원형 그래프로 표현하시오.
install.packages("plotrix")
library(plotrix)
pie3D(Murder_weapon,
      main =  "살인범죄 공용물 사용 빈도",
      col = rainbow(length(Murder_weapon)),
      labels = paste(Murder[2:10,1], ":", Murder[2:10,2]),
      radius =  1)
