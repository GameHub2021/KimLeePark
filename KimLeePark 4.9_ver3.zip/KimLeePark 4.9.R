# 참고자료 : 2022년도 대한민국 여가활동 참여 유형

library(svDialogs)
freetime <- read.csv('2022_freetime.csv', fileEncoding = "CP949", encoding = "UTF-8")
freetime
head(freetime)
class(freetime)
# 요약본 출력
str(freetime)

#1. 여가 활동 인구의 유형을 입력받아 해당되는 유형의 여가 활동 표본을 출력하시오.
input.type <- dlgInput('Input type')$res
freetime_type <- subset(freetime, Total == input.type)
print(freetime_type)

#2. 1번에서 구한 여가 활동 표본을 텍스트 파일로 저장하시오.
sink('text.txt', append = T)
print(freetime_type)
sink()

#3. 여가 활동 인구의 유형과 여가 활동의 종류를 입력받아 해당되는 인구 유형의 여가 활동 중 입력받은 여가 활동의 수치를 출력하시오. 
input.col <- dlgInput('Input col')$res
input.row <- dlgInput('Input row')$res
freetime_wanted <- subset(freetime, Total == input.col)
freetime_wanted[, input.row]
