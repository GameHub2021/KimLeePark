library(svDialogs)
getwd()
setwd("C:\\Rworks")
Restplace <- read.csv('RestPlace.csv', fileEncoding = "CP949", encoding = "UTF-8")
Restplace



fuction