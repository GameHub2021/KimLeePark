library(svDialogs)
freetime <- read.csv('2022_freetime.csv', fileEncoding = "CP949", encoding = "UTF-8")
head(freetime)
class(freetime)
freetime
str(freetime)


input.type <- dlgInput('Input type')$res
freetime_local <- subset(freetime, Total == input.type)
print(freetime_local)


input.col <- dlgInput('Input col')$res
input.row <- dlgInput('Input row')$res
freetime_wanted <- subset(freetime, Total == input.col)
print(freetime_wanted)
freetime_wanted[, input.row]


sink('text.txt', append = T)
print(freetime_local)
sink()